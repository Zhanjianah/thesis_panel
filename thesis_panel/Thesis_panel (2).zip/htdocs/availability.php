<?php
require_once 'database.php';
session_start();

if (empty($_SESSION['teacher_id'])) {
    header('Location: login.php');
    exit;
}

$teacher_id = $_SESSION['teacher_id'];
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = $_POST['available_date'] ?? '';
    $start_time = $_POST['start_time'] ?? '';
    $end_time = $_POST['end_time'] ?? '';

    if (empty($date) || empty($start_time) || empty($end_time)) {
        $error = 'Please complete all fields.';
    } elseif ($start_time >= $end_time) {
        $error = 'End time must be later than start time.';
    } else {
        // Check for duplicate before inserting
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM availability WHERE teacher_id = ? AND available_date = ? AND start_time = ? AND end_time = ?");
        $stmt->execute([$teacher_id, $date, $start_time, $end_time]);
        if ($stmt->fetchColumn() > 0) {
            $error = 'This availability slot already exists.';
        } else {
            $stmt = $pdo->prepare("INSERT INTO availability (teacher_id, available_date, start_time, end_time) VALUES (?, ?, ?, ?)");
            $stmt->execute([$teacher_id, $date, $start_time, $end_time]);
            $success = 'Availability added successfully.';
        }
    }
}

// Fetch current availability
$stmt = $pdo->prepare("SELECT * FROM availability WHERE teacher_id = ? ORDER BY available_date, start_time");
$stmt->execute([$teacher_id]);
$availability = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Set Availability</title>
    <link rel="stylesheet" href="availability.css">
</head>
<body>
<div class="container">
    <h2>Set Your Availability</h2>

    <!-- Back to Dashboard Button -->
    <a href="dashboard.php" class="btn-back">← Back to Dashboard</a>

    <?php if ($success): ?><p class="success"><?= htmlspecialchars($success) ?></p><?php endif; ?>
    <?php if ($error): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>

    <form method="post">
        <label>Date:</label>
        <input type="date" name="available_date" required min="<?= date('Y-m-d') ?>">

        <label>Start Time:</label>
        <input type="time" name="start_time" required>

        <label>End Time:</label>
        <input type="time" name="end_time" required>

        <button type="submit">Add Availability</button>
    </form>

    <h3>Your Availability</h3>
    <?php if (empty($availability)): ?>
        <p>No availability added yet.</p>
    <?php else: ?>
        <table>
            <tr>
                <th>Date</th>
                <th>Start Time</th>
                <th>End Time</th>
            </tr>
            <?php foreach ($availability as $a): ?>
                <tr>
                    <td><?= htmlspecialchars($a['available_date']) ?></td>
                    <td><?= date('h:i A', strtotime($a['start_time'])) ?></td>
                    <td><?= date('h:i A', strtotime($a['end_time'])) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</div>
</body>
</html>
