<?php
session_start();
require_once 'database.php';
require_once 'functions.php';

// Only admin can access
if (!is_admin()) {
    header('Location: login.php');
    exit;
}

// Fetch all panels
$panels = $pdo->query("
    SELECT 
        p.id,
        s.full_name AS student_name,
        s.course AS student_course,
        p.thesis_title,
        p.defense_date,
        p.defense_time,
        p.venue,
        p.panel_members,
        p.status
    FROM panels p
    JOIN students s ON p.student_id = s.id
    ORDER BY p.defense_date DESC, p.defense_time DESC
")->fetchAll(PDO::FETCH_ASSOC);

// Fetch all teachers as [id => full_name]
$teachers = $pdo->query("SELECT id, full_name FROM teachers")->fetchAll(PDO::FETCH_KEY_PAIR);

// KPI Calculations
$total_panels = count($panels);
$approved_panels = count(array_filter($panels, fn($p) => $p['status'] === 'approved'));
$pending_panels = count(array_filter($panels, fn($p) => $p['status'] === 'pending'));
$rejected_panels = count(array_filter($panels, fn($p) => $p['status'] === 'rejected'));


// Helper to get teacher names from CSV
function get_panel_members($panel_members_csv, $all_teachers) {
    $ids = array_filter(explode(',', $panel_members_csv));
    $names = [];
    foreach ($ids as $id) {
        $id = trim($id);
        if (isset($all_teachers[$id])) {
            $names[] = $all_teachers[$id];
        }
    }
    return implode(', ', $names);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Reports</title>
    <link rel="stylesheet" href="report.css">
</head>
<body>
<div class="dashboard-container">
    <header>
        <h2>Reports</h2>
        <nav>
            <a href="admin_dashboard.php" class="nav-link">Dashboard</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </nav>
    </header>

    <!-- ===== KPI CARDS ===== -->
    <div class="kpi-container">
        <div class="kpi-card total">
            <h4>Total Panels</h4>
            <p><?= $total_panels ?></p>
        </div>
        <div class="kpi-card approved">
            <h4>Approved Panels</h4>
            <p><?= $approved_panels ?></p>
        </div>
        <div class="kpi-card pending">
            <h4>Pending Panels</h4>
            <p><?= $pending_panels ?></p>
        </div>
        <div class="kpi-card rejected">
    <h4>Rejected Panels</h4>
    <p><?= $rejected_panels ?></p>
</div>

    </div>

    <!-- ===== FULL PANEL LIST ===== -->
    <section>
        <h3>All Thesis Panels</h3>
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Student</th>
                    <th>Course</th>
                    <th>Thesis Title</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Venue</th>
                    <th>Panel Members</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($panels)): ?>
                    <tr><td colspan="9" class="empty">No panels found.</td></tr>
                <?php else: ?>
                    <?php foreach ($panels as $p): ?>
                        <tr>
                            <td><?= htmlspecialchars($p['id']) ?></td>
                            <td><?= htmlspecialchars($p['student_name']) ?></td>
                            <td><?= htmlspecialchars($p['student_course']) ?></td>
                            <td><?= htmlspecialchars($p['thesis_title']) ?></td>
                            <td><?= htmlspecialchars($p['defense_date']) ?></td>
                            <td><?= htmlspecialchars(date('h:i A', strtotime($p['defense_time']))) ?></td>
                            <td><?= htmlspecialchars($p['venue'] ?: 'TBD') ?></td>
                            <td><?= htmlspecialchars(get_panel_members($p['panel_members'], $teachers)) ?></td>
                            <td class="status <?= 'status-' . htmlspecialchars($p['status']) ?>">
                                <?= htmlspecialchars(ucfirst($p['status'])) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </section>
</div>
</body>
</html>
