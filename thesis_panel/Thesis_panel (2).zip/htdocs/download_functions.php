<?php
/**
 * Download / Print related helper functions
 */

/**
 * Get approved schedule details for a student
 */
function get_approved_schedule_details(PDO $pdo, $student_id, $panel_id)
{
    $sql = "
        SELECT 
            p.id,
            p.thesis_title,
            p.panel_members,
            p.defense_date,
            p.defense_time,
            p.defense_end_time,
            p.venue,
            s.full_name AS student_name
        FROM panels p
        JOIN students s ON s.id = p.student_id
        WHERE p.status = 'approved'
          AND p.student_id = :student_id
          AND p.id = :panel_id
        LIMIT 1
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':student_id' => $student_id,
        ':panel_id'   => $panel_id
    ]);

    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Convert panel member IDs to names
 */
function get_panel_member_names(PDO $pdo, $panel_members)
{
    if (empty($panel_members)) {
        return [];
    }

    // panel_members is stored as comma-separated IDs
    $ids = array_map('intval', explode(',', $panel_members));
    $placeholders = implode(',', array_fill(0, count($ids), '?'));

    $sql = "
        SELECT full_name
        FROM teachers
        WHERE id IN ($placeholders)
        ORDER BY full_name
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($ids);

    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

/**
 * Generate printable HTML
 */
function generate_schedule_html(array $schedule, array $panel_members)
{
    $panel_list = empty($panel_members)
        ? 'N/A'
        : implode(', ', $panel_members);

    $date = date('F d, Y', strtotime($schedule['defense_date']));
    $start_time = date('g:i A', strtotime($schedule['defense_time']));
    $end_time = date('g:i A', strtotime($schedule['defense_end_time']));

    ob_start();
    ?>
<!DOCTYPE html>
<html>
<head>
    <title>Thesis Defense Schedule</title>
    <link rel="stylesheet" href="print_schedule.css">
    
</head>
<body>

    <button onclick="window.print()">Print</button>

    <h1>Thesis Defense Schedule</h1>

    <div class="details">
        <p><strong>Student Name:</strong> <?= htmlspecialchars($schedule['student_name']) ?></p>
        <p><strong>Thesis Title:</strong> <?= htmlspecialchars($schedule['thesis_title']) ?></p>
        <p><strong>Panel Members:</strong> <?= htmlspecialchars($panel_list) ?></p>
        <p><strong>Date:</strong> <?= $date ?></p>
        <p><strong>Time:</strong> <?= $start_time ?> – <?= $end_time ?></p>
        <p><strong>Venue:</strong> <?= htmlspecialchars($schedule['venue']) ?></p>
    </div>

    <div class="footer">
        <p>This document is system-generated.</p>
    </div>

</body>
</html>
    <?php
    return ob_get_clean();
}
