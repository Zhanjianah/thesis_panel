<?php
require_once 'database.php';
require_once 'EmailVerification.php';
session_start();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $login_email = trim($_POST['email'] ?? '');
    $personal_email = trim($_POST['personal_email'] ?? '');
    $department = trim($_POST['department'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    // Validation
    if ($full_name === '' || $login_email === '' || $personal_email === '' || $password === '' || $department === '') {
        $errors[] = 'All fields are required.';
    }
    if (!filter_var($login_email, FILTER_VALIDATE_EMAIL) || !filter_var($personal_email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email format.';
    }
    if ($password !== $password_confirm) {
        $errors[] = 'Passwords do not match.';
    }

    // Check if login email exists
    $stmt = $pdo->prepare("SELECT id FROM students WHERE email = ?");
    $stmt->execute([$login_email]);
    if ($stmt->fetch()) $errors[] = 'Login email already exists.';

    if (empty($errors)) {
        $_SESSION['verification'] = true;
        $_SESSION['full_name'] = $full_name;
        $_SESSION['login_email'] = $login_email;
        $_SESSION['personal_email'] = $personal_email;
        $_SESSION['department'] = $department;
        $_SESSION['password'] = $password;

        // Generate PIN & send email
        $emailVerifier = new EmailVerification();
        $pin_code = [];
        $emailVerifier->sendVerificationEmail($personal_email, $full_name, $pin_code);
        $_SESSION['pin_code'] = $pin_code;

        header("Location: verification.php?user_type=student");
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register Student</title>
  <link rel="stylesheet" href="student_register.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
</head>
<body>
  <div class="register-box">
    <h2>Student Registration</h2>
    
    <?php if (!empty($errors)): ?>
      <ul>
        <?php foreach($errors as $e): ?>
          <li><?= htmlspecialchars($e) ?></li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>

    <form method="post">
      <label>
        Full Name
        <input type="text" name="full_name" required value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>">
      </label>

      <label>
        Login Email
        <input type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
      </label>

      <label>
        Personal Email (for verification)
        <input type="email" name="personal_email" required value="<?= htmlspecialchars($_POST['personal_email'] ?? '') ?>">
      </label>

      <label>
        Department
        <input type="text" name="department" required value="<?= htmlspecialchars($_POST['department'] ?? '') ?>">
      </label>

      <label>
        Password
        <input type="password" name="password" required>
      </label>

      <label>
        Confirm Password
        <input type="password" name="password_confirm" required>
      </label>

      <button type="submit">Register</button>
    </form>

    <p>Already have an account? <a href="student_login.php">Login</a></p>
  </div>
</body>
</html>