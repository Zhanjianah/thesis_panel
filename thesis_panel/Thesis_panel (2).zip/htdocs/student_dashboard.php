<?php
require_once 'database.php';
require_once 'notification_functions.php'; // starts session if not started

// Ensure student is logged in
if (empty($_SESSION['student_id'])) {
    header('Location: student_login.php');
    exit;
}

$student_id = $_SESSION['student_id'];

// Fetch all non-admin teachers
$teachers = $pdo->query("
    SELECT id, full_name, department 
    FROM teachers 
    WHERE is_admin = 0 
    ORDER BY full_name
")->fetchAll();

// Fetch panels created by this student
$stmt = $pdo->prepare("
    SELECT 
        p.id, 
        p.thesis_title, 
        p.defense_date, 
        p.defense_time, 
        r.room_name AS venue_name,
        p.status 
    FROM panels p
    LEFT JOIN rooms r ON r.room_name = p.venue
    WHERE p.student_id = ?
    ORDER BY p.defense_date DESC, p.defense_time DESC
");
$stmt->execute([$student_id]);
$panels = $stmt->fetchAll();

// Fetch count of unread notifications for bell badge
$unread_count = count_unread_notifications($student_id);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="student_dashboard.css">
</head>
<body>

<div class="dashboard-container">
    <header>
        <h2>Welcome, <?= htmlspecialchars($_SESSION['student_name']) ?></h2>
        <div>
            <a href="view_notifications_student.php" class="notification-bell">
                
                🔔
                <?php if ($unread_count > 0): ?>
                    <span class="badge"><?= $unread_count ?></span>
                <?php endif; ?>
            </a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </header>

    <?php if (!empty($_SESSION['success'])): ?>
        <p class="success-msg"><?= htmlspecialchars($_SESSION['success']) ?></p>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <section class="schedule-section">
        <h3>
            <a href="student_schedule_create.php" class="new-request-btn">
                Request New Thesis Defense Schedule
            </a>
        </h3>

        <h3>Your Panel Requests</h3>
        <table class="data-table" border="1" cellpadding="5" cellspacing="0">
            <thead>
                <tr>
                    <th>Thesis Title</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Venue</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($panels)): ?>
                <tr><td colspan="6">No schedule requests found.</td></tr>
            <?php else: ?>
                <?php foreach ($panels as $p): ?>
                    <?php $status_class = 'status-' . htmlspecialchars($p['status']); ?>
                    <tr>
                        <td><?= htmlspecialchars($p['thesis_title']) ?></td>
                        <td><?= htmlspecialchars($p['defense_date']) ?></td>
                        <td><?= htmlspecialchars($p['defense_time']) ?></td>
                        <td><?= htmlspecialchars($p['venue_name'] ?: 'TBD') ?></td>
                        <td class="<?= $status_class ?>"><?= htmlspecialchars(ucfirst($p['status'])) ?></td>
                        <td>
                            <?php if ($p['status'] === 'pending'): ?>
                                <a href="student_schedule_edit.php?id=<?= $p['id'] ?>" class="edit-link">Edit</a>

                                |
                                <form method="post" action="process_panel.php" style="display:inline;">
                                    <input type="hidden" name="action" value="delete_student_schedule">
                                    <input type="hidden" name="id" value="<?= $p['id'] ?>">
                                    <button type="submit" class="delete-btn" onclick="return confirm('Are you sure you want to delete this pending request?')">Delete</button>

                                </form>
                            <?php elseif ($p['status'] === 'approved'): ?>
                                <!-- NEW: Added Download/Print button for approved schedules -->
                                <a href="print_schedule.php?id=<?= $p['id'] ?>" class="download-btn" target="_blank">📄 Download/Print</a>
                                No other actions
                            <?php else: ?>
                                No actions
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </section>

    <section class="teacher-section">
        <h3>Teacher Information</h3>
        <p>Consult these teachers' registered availability when submitting your schedule request.</p>
        <table class="data-table" border="1" cellpadding="5" cellspacing="0">
            <thead>
                <tr><th>Name</th><th>Department</th></tr>
            </thead>
            <tbody>
                <?php foreach ($teachers as $t): ?>
                    <tr>
                        <td><?= htmlspecialchars($t['full_name']) ?></td>
                        <td><?= htmlspecialchars($t['department']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
</div>

</body>
</html>