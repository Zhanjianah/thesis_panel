<?php
/**
 * Print / Download Schedule Page
 */

require_once 'database.php';
require_once 'download_functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ensure student is logged in
if (empty($_SESSION['student_id'])) {
    header('Location: student_login.php');
    exit;
}

$student_id = $_SESSION['student_id'];
$panel_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch the approved schedule
$schedule = get_approved_schedule_details($pdo, $student_id, $panel_id);

// If no schedule found or not approved
if (!$schedule) {
    $_SESSION['error'] = 'Schedule not found or not yet approved.';
    header('Location: student_dashboard.php');
    exit;
}

// Get panel member names
$panel_members = get_panel_member_names($pdo, $schedule['panel_members']);

// Output printable HTML
echo generate_schedule_html($schedule, $panel_members);
