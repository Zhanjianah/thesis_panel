<?php
require_once 'database.php';
require_once 'functions.php';
if (!is_logged_in()) header('Location: login.php');

$uid = current_user_id();
$admin = is_admin();

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) die('Invalid panel ID.');

$stmt = $pdo->prepare("SELECT * FROM panels WHERE id = ?");
$stmt->execute([$id]);
$panel = $stmt->fetch();
if (!$panel) die('Panel not found.');

if (!$admin && $panel['creator_id'] != $uid) die('Not authorized.');

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_name = trim($_POST['student_name'] ?? '');
    $thesis_title = trim($_POST['thesis_title'] ?? '');
    $scheduled_date = $_POST['scheduled_date'] ?? '';
    $scheduled_time = $_POST['scheduled_time'] ?? '';
    $venue = trim($_POST['venue'] ?? '');
    $panel_member_ids = $_POST['panel_members'] ?? [];
    $panel_member_ids = array_map('intval', $panel_member_ids);
    $panel_member_ids = array_values(array_unique($panel_member_ids));
    $status = $_POST['status'] ?? $panel['status'];

    if ($student_name === '' || $thesis_title === '' || !$scheduled_date || !$scheduled_time) {
        $errors[] = 'Student, title, date, time required.';
    }
    if (empty($panel_member_ids)) $errors[] = 'Select at least one panel member.';

    if (empty($errors)) {
        $conflicts = check_conflicts($pdo, $scheduled_date, $scheduled_time, $panel_member_ids, $id);
        if (!empty($conflicts)) {
            $names = [];
            foreach ($conflicts as $c) $names[] = teacher_name_by_id($pdo, $c);
            $errors[] = 'Conflict with teachers: ' . implode(', ', $names);
        } else {
            $member_lines = [];
            foreach ($panel_member_ids as $pid) $member_lines[] = $pid . '|' . teacher_name_by_id($pdo, $pid);
            $panel_txt = implode("\n", $member_lines);
            $stmt = $pdo->prepare("UPDATE panels SET student_name = ?, thesis_title = ?, scheduled_date = ?, scheduled_time = ?, venue = ?, panel_members = ?, status = ? WHERE id = ?");
            $stmt->execute([$student_name, $thesis_title, $scheduled_date, $scheduled_time, $venue, $panel_txt, $status, $id]);

            // --- SYSTEM NOTIFICATION for Admin ---
            require_once 'notification_functions.php';
            $admin_id = 1; // Replace with actual admin user ID
            $notif_msg = "Panel schedule updated: $student_name ($thesis_title) on $scheduled_date at $scheduled_time";
            add_notification($admin_id, 'update_panel', $notif_msg);

            // --- EMAIL NOTIFICATION to Admin ---
            require_once 'email_functions.php';
            $email_subject = "Panel Schedule Updated";
            $email_body = "$student_name has updated a thesis panel schedule.<br>Title: $thesis_title<br>Date: $scheduled_date<br>Time: $scheduled_time<br>Venue: $venue";
            send_email('admin@example.com', $email_subject, $email_body);

            $success = 'Panel updated.';
            // Refresh panel data
            $stmt = $pdo->prepare("SELECT * FROM panels WHERE id = ?");
            $stmt->execute([$id]);
            $panel = $stmt->fetch();
        }
    }
}

// fetch teachers
$stmt = $pdo->query("SELECT id, full_name, department FROM teachers ORDER BY full_name");
$teachers = $stmt->fetchAll();
$selected_ids = [];
foreach (explode("\n", $panel['panel_members']) as $line) {
    if (strpos($line, '|') !== false) {
        [$tid, $tname] = explode('|', $line, 2);
        $selected_ids[] = (int)$tid;
    }
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Edit Panel</title></head><body>
<h2>Edit Panel (ID <?=htmlspecialchars($panel['id'])?>)</h2>
<p><a href="dashboard.php">Back</a></p>
<?php if ($success) echo '<p>'.htmlspecialchars($success).'</p>'; ?>
<?php if (!empty($errors)) { echo '<ul>'; foreach ($errors as $e) echo '<li>'.htmlspecialchars($e).'</li>'; echo '</ul>'; } ?>

<form method="post" action="">
  <label>Student name: <input type="text" name="student_name" value="<?=htmlspecialchars($panel['student_name'])?>" required></label><br>
  <label>Thesis title: <input type="text" name="thesis_title" value="<?=htmlspecialchars($panel['thesis_title'])?>" required></label><br>
  <label>Date: <input type="date" name="scheduled_date" value="<?=htmlspecialchars($panel['scheduled_date'])?>" required></label><br>
  <label>Time: <input type="time" name="scheduled_time" value="<?=htmlspecialchars($panel['scheduled_time'])?>" required></label><br>
  <label>Venue: <input type="text" name="venue" value="<?=htmlspecialchars($panel['venue'])?>"></label><br>

  <fieldset><legend>Panel Members</legend>
    <?php foreach ($teachers as $t): $checked = in_array((int)$t['id'], $selected_ids) ? 'checked' : ''; ?>
      <label>
        <input type="checkbox" name="panel_members[]" value="<?=htmlspecialchars($t['id'])?>" <?= $checked ?>>
        <?=htmlspecialchars($t['full_name'] . ' (' . $t['department'] . ')')?>
      </label><br>
    <?php endforeach; ?>
  </fieldset>

  <?php if ($admin): ?>
    <label>Status:
      <select name="status">
        <option value="pending" <?= $panel['status']==='pending' ? 'selected':'' ?>>pending</option>
        <option value="approved" <?= $panel['status']==='approved' ? 'selected':'' ?>>approved</option>
        <option value="rejected" <?= $panel['status']==='rejected' ? 'selected':'' ?>>rejected</option>
        <option value="completed" <?= $panel['status']==='completed' ? 'selected':'' ?>>completed</option>
      </select>
    </label><br>
  <?php endif; ?>

  <button type="submit">Save</button>
</form>
</body></html>
