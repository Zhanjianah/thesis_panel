<?php
session_start();
require_once 'database.php';
require_once 'functions.php';

// --- ADMIN CHECK ---
if (!is_admin()) {
    header('Location: login.php');
    exit;
}

// --- FETCH TEACHERS AND THEIR PANEL COUNTS ---
$teachers = $pdo->query("
    SELECT t.id, t.full_name, t.department,
           COUNT(p.id) AS total_panels_assigned
    FROM teachers t
    LEFT JOIN panels p ON FIND_IN_SET(t.id, p.panel_members)
    GROUP BY t.id, t.full_name, t.department
    ORDER BY t.full_name
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Teacher List</title>
    <link rel="stylesheet" href="teacher_list.css">
</head>
<body>
<div class="dashboard-container">
    <header>
        <h2>Teacher List</h2>
        <nav>
            <a href="admin_dashboard.php" class="nav-link">Dashboard</a>
            <a href="panel_list.php" class="nav-link">Panel List</a>
            <a href="student_list.php" class="nav-link">Student List</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </nav>
    </header>

    <h3>All Registered Teachers</h3>
    <table class="data-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Teacher Name</th>
                <th>Department</th>
                <th>Total Panels Assigned</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($teachers)): ?>
                <tr><td colspan="4" class="empty">No teachers found.</td></tr>
            <?php else: ?>
                <?php $serial = 1; ?>
                <?php foreach ($teachers as $teacher): ?>
                    <tr>
                        <td><?= $serial++ ?></td>
                        <td><?= htmlspecialchars($teacher['full_name']) ?></td>
                        <td><?= htmlspecialchars($teacher['department']) ?></td>
                        <td><?= htmlspecialchars($teacher['total_panels_assigned']) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
