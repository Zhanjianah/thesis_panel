<?php
require_once 'init.php';

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    $user_type = $_SESSION['user_type'] ?? null;
    
    // Redirect to appropriate dashboard based on user type
    if ($user_type === 'admin') {
        header('Location: admin_dashboard.php');
        exit;
    } elseif ($user_type === 'teacher') {
        header('Location: dashboard.php');
        exit;
    } elseif ($user_type === 'student') {
        header('Location: student_dashboard.php');
        exit;
    }
}

// If not logged in, check which login page to show
$requested_page = isset($_GET['page']) ? strtolower($_GET['page']) : 'teacher';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PANEL - Authentication System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            max-width: 500px;
            width: 100%;
            padding: 40px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .header h1 {
            color: #333;
            margin-bottom: 10px;
            font-size: 2.5em;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .header p {
            color: #666;
            font-size: 0.95em;
        }
        
        .login-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            border-bottom: 2px solid #eee;
        }
        
        .tab-button {
            flex: 1;
            padding: 12px;
            border: none;
            background: none;
            cursor: pointer;
            font-size: 1em;
            color: #666;
            font-weight: 500;
            border-bottom: 3px solid transparent;
            transition: all 0.3s ease;
        }
        
        .tab-button.active {
            color: #667eea;
            border-bottom-color: #667eea;
        }
        
        .tab-button:hover {
            color: #667eea;
        }
        
        .login-form {
            display: none;
        }
        
        .login-form.active {
            display: block;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
            font-size: 0.95em;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 5px;
            font-size: 0.95em;
            transition: border-color 0.3s ease;
            font-family: inherit;
        }
        
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .form-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
        }
        
        .btn {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 5px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }
        
        .btn-register {
            background: #f0f0f0;
            color: #333;
            border: 2px solid #e0e0e0;
        }
        
        .btn-register:hover {
            background: #e8e8e8;
            border-color: #667eea;
            color: #667eea;
        }
        
        .link-section {
            text-align: center;
            color: #666;
            font-size: 0.9em;
        }
        
        .link-section a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }
        
        .link-section a:hover {
            text-decoration: underline;
        }
        
        .error-message {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #c33;
            display: none;
        }
        
        .error-message.show {
            display: block;
        }
        
        .info-text {
            background: #f0f7ff;
            color: #0066cc;
            padding: 12px;
            border-radius: 5px;
            font-size: 0.9em;
            margin-bottom: 20px;
            border-left: 4px solid #0066cc;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>PANEL</h1>
            <p>Defense Schedule Management System</p>
        </div>
        
        <!-- Login Tabs -->
        <div class="login-tabs">
            <button class="tab-button <?php echo $requested_page === 'teacher' ? 'active' : ''; ?>" onclick="switchTab('teacher')">
                Teacher Login
            </button>
            <button class="tab-button <?php echo $requested_page === 'student' ? 'active' : ''; ?>" onclick="switchTab('student')">
                Student Login
            </button>
        </div>
        
        <!-- Teacher Login Form -->
        <form class="login-form <?php echo $requested_page === 'teacher' ? 'active' : ''; ?>" id="teacher-form" action="login.php" method="POST">
            <input type="hidden" name="user_type" value="teacher">
            <div class="error-message" id="teacher-error"></div>
            
            <div class="form-group">
                <label for="teacher-email">Email Address</label>
                <input type="email" id="teacher-email" name="email" placeholder="Enter your email" required>
            </div>
            
            <div class="form-group">
                <label for="teacher-password">Password</label>
                <input type="password" id="teacher-password" name="password" placeholder="Enter your password" required>
            </div>
            
            <div class="form-buttons">
                <button type="submit" class="btn btn-login">Login</button>
                <a href="register_teacher.php" class="btn btn-register" style="text-decoration: none; display: flex; align-items: center; justify-content: center;">Register</a>
            </div>
        </form>
        
        <!-- Student Login Form -->
        <form class="login-form <?php echo $requested_page === 'student' ? 'active' : ''; ?>" id="student-form" action="student_login.php" method="POST">
            <input type="hidden" name="user_type" value="student">
            <div class="error-message" id="student-error"></div>
            
            <div class="info-text">
                👤 Login with your student credentials to access your defense schedule
            </div>
            
            <div class="form-group">
                <label for="student-email">Email Address</label>
                <input type="email" id="student-email" name="email" placeholder="Enter your student email" required>
            </div>
            
            <div class="form-group">
                <label for="student-password">Password</label>
                <input type="password" id="student-password" name="password" placeholder="Enter your password" required>
            </div>
            
            <div class="form-buttons">
                <button type="submit" class="btn btn-login">Login</button>
                <a href="student_register.php" class="btn btn-register" style="text-decoration: none; display: flex; align-items: center; justify-content: center;">Register</a>
            </div>
        </form>
        
        <!-- Footer -->
        <div class="link-section" style="margin-top: 30px;">
            <p>Having issues? <a href="mailto:support@yourdomain.com">Contact Support</a></p>
        </div>
    </div>
    
    <script>
        function switchTab(userType) {
            // Update URL without page reload
            window.history.pushState({}, '', '?page=' + userType);
            
            // Hide all forms
            document.querySelectorAll('.login-form').forEach(form => {
                form.classList.remove('active');
            });
            
            // Remove active class from all buttons
            document.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Show selected form
            if (userType === 'teacher') {
                document.getElementById('teacher-form').classList.add('active');
                document.querySelectorAll('.tab-button')[0].classList.add('active');
            } else if (userType === 'student') {
                document.getElementById('student-form').classList.add('active');
                document.querySelectorAll('.tab-button')[1].classList.add('active');
            }
        }
        
        // Check for error messages from query string
        const urlParams = new URLSearchParams(window.location.search);
        const error = urlParams.get('error');
        const page = urlParams.get('page') || 'teacher';
        
        if (error) {
            const errorElement = document.getElementById(page + '-error');
            if (errorElement) {
                errorElement.textContent = decodeURIComponent(error);
                errorElement.classList.add('show');
            }
        }
    </script>
</body>
</html>
