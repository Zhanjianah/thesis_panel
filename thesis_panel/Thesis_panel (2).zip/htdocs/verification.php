<?php
require_once 'database.php';
require_once 'notification_functions.php'; // AFTER database.php

// Start session only if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$errors = [];

if (!isset($_SESSION['verification']) || !isset($_SESSION['pin_code'])) {
    header("Location: login.php");
    exit;
}

$user_type = $_GET['user_type'] ?? '';
$input_pin = $_POST['pin_code'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($input_pin == $_SESSION['pin_code']) {

        $hash = password_hash($_SESSION['password'], PASSWORD_DEFAULT);

        // INSERT FOR TEACHER
        if ($user_type === 'teacher') {
            $stmt = $pdo->prepare("INSERT INTO teachers
                (full_name,email,personal_email,password,department,is_admin,email_verified)
                VALUES (?,?,?,?,?,?,1)");
            $stmt->execute([
                $_SESSION['full_name'],
                $_SESSION['login_email'],
                $_SESSION['personal_email'],
                $hash,
                $_SESSION['department'],
                $_SESSION['is_admin']
            ]);

            //  CREATE NOTIFICATION FOR ADMINS
            // Adjust table/column if your admins are in 'teachers' table
            $admins = $pdo->query("SELECT id FROM teachers WHERE is_admin = 1")
                          ->fetchAll(PDO::FETCH_ASSOC);

            foreach ($admins as $admin) {
                add_notification(
                    $admin['id'],
                    'teacher_registration',
                    'A new teacher has registered and is awaiting approval.',
                    'teacher_list.php'
                );
            }
        } 
        // INSERT FOR STUDENT
        elseif ($user_type === 'student') {
            $stmt = $pdo->prepare("INSERT INTO students
                (full_name,email,personal_email,password,course,email_verified)
                VALUES (?,?,?,?,?,1)");
            $stmt->execute([
                $_SESSION['full_name'],
                $_SESSION['login_email'],
                $_SESSION['personal_email'],
                $hash,
                $_SESSION['course']
            ]);
        }

        // Clear session
        unset($_SESSION['verification']);
        unset($_SESSION['full_name']);
        unset($_SESSION['login_email']);
        unset($_SESSION['personal_email']);
        unset($_SESSION['department']);
        unset($_SESSION['course']);
        unset($_SESSION['password']);
        unset($_SESSION['is_admin']);
        unset($_SESSION['pin_code']);

        header("Location: login.php?success=verified");
        exit;
    } else {
        $errors[] = "Incorrect PIN code.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Email Verification</title>
<link rel="stylesheet" href="verification.css">
</head>
<body>

<div class="verification-container">
  <div class="icon-wrapper">
    <svg fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24">
      <path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
    </svg>
  </div>
  
  <h2>Verify Your Email</h2>
  <p class="subtitle">Enter the 6-digit PIN sent to your email.</p>
  
  <?php foreach($errors as $e): ?>
    <div class="error-message"><?php echo htmlspecialchars($e); ?></div>
  <?php endforeach; ?>
  
  <form method="post">
    <div class="input-group">
      <input type="text" name="pin_code" placeholder="000000" required>
    </div>
    <button type="submit">Verify Email</button>
  </form>
</div>

</body>
</html>
