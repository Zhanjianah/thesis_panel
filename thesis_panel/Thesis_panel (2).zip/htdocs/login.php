<?php 
require_once 'database.php';
session_start();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $errors[] = 'Email and password are required.';
    } else {
        // 1. Check if it's a teacher/admin
        $stmt = $pdo->prepare("SELECT id, password, full_name, is_admin, email_verified FROM teachers WHERE email = ?");
        $stmt->execute([$email]);
        $teacher = $stmt->fetch();

        if ($teacher && password_verify($password, $teacher['password'])) {
            if ($teacher['email_verified'] == 0) {
                $errors[] = "Please verify your account using the PIN sent to your personal email.";
            } else {
                $_SESSION['teacher_id'] = $teacher['id'];
                $_SESSION['teacher_name'] = $teacher['full_name'];
                $_SESSION['is_admin'] = (int)$teacher['is_admin'];

                header($teacher['is_admin'] ? 'Location: admin_dashboard.php' : 'Location: dashboard.php');
                exit;
            }
        } else {
            // 2. Check if it's a student
            $stmt = $pdo->prepare("SELECT id, password, full_name FROM students WHERE email = ?");
            $stmt->execute([$email]);
            $student = $stmt->fetch();

            if ($student && password_verify($password, $student['password'])) {
                $_SESSION['student_id'] = $student['id'];
                $_SESSION['student_name'] = $student['full_name'];
                header('Location: student_dashboard.php');
                exit;
            } else {
                // 3. If neither teacher nor student found
                $errors[] = 'Invalid email or password.';
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Login</title>
  <link rel="stylesheet" href="login.css">
</head>
<body>
  <div class="login-container" role="main" aria-labelledby="login-heading">
    <h2 id="login-heading">Login</h2>

    <?php if (!empty($_SESSION['success'])): ?>
      <div class="success" role="status"><?= htmlspecialchars($_SESSION['success']) ?></div>
      <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <?php if (!empty($errors)): ?>
      <div class="error-list" role="alert">
        <ul>
          <?php foreach ($errors as $e): ?>
            <li><?= htmlspecialchars($e) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="post" action="" novalidate>
      <div class="form-group">
        <label for="email">Email</label>
        <input id="email" type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
      </div>

      <div class="form-group">
        <label for="password">Password</label>
        <input id="password" type="password" name="password" required>
      </div>

      <div class="form-group">
        <button type="submit">Login</button>
      </div>
    </form>

    <div class="footer-links" aria-hidden="false">
      <p>Switch to <a href="student_login.php">Student Login</a></p>
      <p><a href="register_teacher.php">Register as Teacher</a></p>
    </div>
  </div>
</body>
</html>
