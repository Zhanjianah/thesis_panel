<?php
require_once 'database.php';
require_once 'notification_functions.php';

$token = $_GET['token'] ?? '';
$user = $_GET['user'] ?? '';

if ($token && ($user === 'teacher' || $user === 'student')) {
    $table = $user === 'teacher' ? 'teachers' : 'students';
    $stmt = $pdo->prepare("SELECT id, full_name FROM $table WHERE email_verification_token = ?");
    $stmt->execute([$token]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        $id = $row['id'];
        $name = $row['full_name'];
        $stmt = $pdo->prepare("UPDATE $table SET email_verified = 1, email_verification_token = NULL WHERE id = ?");
        $stmt->execute([$id]);

        echo "Email verified successfully. You can now login.";

        // Notify all admins
        $admins = $pdo->query("SELECT id FROM teachers WHERE is_admin = 1")->fetchAll(PDO::FETCH_COLUMN);
        $type = $user === 'teacher' ? 'teacher_verified' : 'student_verified';
        foreach ($admins as $admin_id) {
            add_notification($admin_id, $type, ucfirst($user) . " '{$name}' has verified their email.", "admin_dashboard.php");
        }
    } else {
        echo "Invalid or expired verification link.";
    }
} else {
    echo "Invalid request.";
}
