<?php
// database.php
$DB_HOST = 'sql313.infinityfree.com';
$DB_NAME = 'if0_40679751_thesis_panel';
$DB_USER = 'if0_40679751';
$DB_PASS = 'ICOvqJ9BGDfLKqZ';

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
} catch (PDOException $e) {
    die('DB Connection failed: ' . $e->getMessage());
}
