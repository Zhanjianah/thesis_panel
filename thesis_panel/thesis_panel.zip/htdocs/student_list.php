<?php
session_start();
require_once 'database.php';
require_once 'functions.php';

// --- ADMIN CHECK ---
if (!is_admin()) {
    header('Location: login.php');
    exit;
}

// --- FETCH STUDENTS ---
$students = $pdo->query("
    SELECT s.id, s.full_name, s.course,
           COUNT(p.id) AS total_panels
    FROM students s
    LEFT JOIN panels p ON s.id = p.student_id
    GROUP BY s.id, s.full_name, s.course
    ORDER BY s.full_name
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student List</title>
    <link rel="stylesheet" href="student_list.css">
</head>
<body>
<div class="dashboard-container">
    <header>
        <h2>Student List</h2>
        <nav>
            <a href="admin_dashboard.php" class="nav-link">Dashboard</a>
            <a href="panel_list.php" class="nav-link">Panel List</a>
            <a href="teacher_list.php" class="nav-link">Teacher List</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </nav>
    </header>

    <h3>All Registered Students</h3>
    <table class="data-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Student Name</th>
                <th>Course</th>
                <th>Total Panels Submitted</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($students)): ?>
                <tr><td colspan="4" class="empty">No students found.</td></tr>
            <?php else: ?>
                <?php $serial = 1; ?>
                <?php foreach ($students as $student): ?>
                    <tr>
                        <td><?= $serial++ ?></td>
                        <td><?= htmlspecialchars($student['full_name']) ?></td>
                        <td><?= htmlspecialchars($student['course']) ?></td>
                        <td><?= htmlspecialchars($student['total_panels']) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
