<?php
require_once 'database.php';
require_once 'notification_functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $errors[] = 'Email and password are required.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM students WHERE email = ?");
        $stmt->execute([$email]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$student) {
            $errors[] = 'Invalid email or password.';
        } else {
            // Check password: plain text fallback if needed
            $passwordMatch = password_verify($password, $student['password']) 
                             || $student['password'] === $password;

            if (!$passwordMatch) {
                $errors[] = 'Invalid email or password.';
            } else {
                // Check if email is verified
                if ($student['email_verified'] == 0) {
                    $errors[] = "Please verify your account using the PIN sent to your personal email.";
                } else {
                    // Set session variables and redirect
                    $_SESSION['student_id'] = $student['id'];
                    $_SESSION['student_name'] = $student['full_name'];
                    header('Location: student_dashboard.php');
                    exit;
                }
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Student Login</title>
  <link rel="stylesheet" href="student_login.css">
</head>
<body>

  <!--  SAME CONTAINER -->
  <div class="login-container" role="main" aria-labelledby="student-login-heading">

    <h2 id="student-login-heading">Student Login</h2>

    <!--  ERROR STYLING MATCHED -->
    <?php if (!empty($errors)): ?>
      <div class="error-list" role="alert">
        <ul>
          <?php foreach ($errors as $e): ?>
            <li><?= htmlspecialchars($e) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <!--  SAME FORM STRUCTURE -->
    <form method="post" novalidate>

      <div class="form-group">
        <label for="email">Email</label>
        <input
          id="email"
          type="email"
          name="email"
          required
          value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
      </div>

      <div class="form-group">
        <label for="password">Password</label>
        <input
          id="password"
          type="password"
          name="password"
          required>
      </div>

      <div class="form-group">
        <button type="submit">Login</button>
      </div>

    </form>

    <!--  FOOTER LINKS MATCHED -->
    <div class="footer-links">
      <p><a href="student_register.php">Register as Student</a></p>
      <p>Switch to <a href="login.php">Teacher / Admin Login</a></p>
    </div>

  </div>
</body>
</html>
