<?php
session_start();
require_once 'database.php';
require_once 'functions.php';

// --- ADMIN CHECK ---
if (!is_admin()) {
    header('Location: login.php');
    exit;
}

// --- FETCH PANELS ---
$panels = $pdo->query("
    SELECT 
        p.id,
        s.full_name AS student_name,
        s.course AS student_course,
        p.thesis_title,
        p.defense_date,
        p.defense_time,
        p.venue,
        p.panel_members,
        p.status
    FROM panels p
    JOIN students s ON p.student_id = s.id
    ORDER BY p.defense_date DESC, p.defense_time DESC
")->fetchAll(PDO::FETCH_ASSOC);

// --- FETCH TEACHERS AS [ID => NAME] ---
$teachers = $pdo->query("SELECT id, full_name FROM teachers")->fetchAll(PDO::FETCH_KEY_PAIR);

// --- HELPER FUNCTION ---
function get_panel_members($panel_members_csv, $all_teachers) {
    $ids = array_filter(explode(',', $panel_members_csv));
    $names = [];
    foreach ($ids as $id) {
        if (isset($all_teachers[$id])) {
            $names[] = $all_teachers[$id];
        }
    }
    return !empty($names) ? implode(', ', $names) : 'No panel assigned';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel List</title>
    <link rel="stylesheet" href="panel_list.css">
</head>
<body>
<div class="dashboard-container">
    <header>
        <h2>Panel List</h2>
        <nav>
            <a href="admin_dashboard.php" class="nav-link">Dashboard</a>
            <a href="lists_reports.php" class="nav-link">All Lists</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </nav>
    </header>

    <h3>All Thesis Panels</h3>
    <table class="data-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Student</th>
                <th>Course</th>
                <th>Thesis Title</th>
                <th>Panel Members</th>
                <th>Date</th>
                <th>Time</th>
                <th>Venue</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($panels)): ?>
                <tr><td colspan="9" class="empty">No panels found.</td></tr>
            <?php else: ?>
                <?php $serial = 1; ?>
                <?php foreach ($panels as $panel): ?>
                    <tr>
                        <td data-label="#"><?= $serial++ ?></td>
                        <td data-label="Student"><?= htmlspecialchars($panel['student_name']) ?></td>
                        <td data-label="Course"><?= htmlspecialchars($panel['student_course']) ?></td>
                        <td data-label="Thesis Title"><?= htmlspecialchars($panel['thesis_title']) ?></td>
                        <td data-label="Panel Members"><?= htmlspecialchars(get_panel_members($panel['panel_members'], $teachers)) ?></td>
                        <td data-label="Date"><?= htmlspecialchars($panel['defense_date']) ?></td>
                        <td data-label="Time"><?= htmlspecialchars(date('h:i A', strtotime($panel['defense_time']))) ?></td>
                        <td data-label="Venue"><?= htmlspecialchars($panel['venue'] ?: 'TBD') ?></td>
                        <td data-label="Status" class="status <?= 'status-' . htmlspecialchars($panel['status']) ?>">
                            <?= htmlspecialchars(ucfirst($panel['status'])) ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
