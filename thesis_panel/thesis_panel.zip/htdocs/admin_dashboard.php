<?php
require_once 'database.php';
require_once 'functions.php';
require_once 'notification_functions.php';

// --- AUTH CHECK ---
if (!is_logged_in() || !is_admin()) {
    header('Location: login.php');
    exit;
}

// --- HANDLE APPROVE / REJECT ACTIONS ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['panel_id'], $_POST['action'])) {
    $panel_id = (int)$_POST['panel_id'];
    $action = $_POST['action'] === 'approve' ? 'approved' : 'rejected';

    try {
        $stmt = $pdo->prepare("UPDATE panels SET status = ? WHERE id = ?");
        $stmt->execute([$action, $panel_id]);
        $_SESSION['success'] = "Schedule ID {$panel_id} {$action} successfully.";

        // Fetch student details including email and name
        $student_stmt = $pdo->prepare("SELECT s.id as student_id, s.email, s.full_name FROM students s JOIN panels p ON s.id = p.student_id WHERE p.id = ?");
        $student_stmt->execute([$panel_id]);
        $student = $student_stmt->fetch(PDO::FETCH_ASSOC);
        
        $student_id = $student['student_id'];
        $student_email = $student['email'];
        $student_name = $student['full_name'];

        // Add system notification
        add_notification($student_id, 'panel_status', "Your panel schedule (ID {$panel_id}) has been {$action}.", "student_dashboard.php");

        // Send email notification
        require_once 'EmailVerification.php';
        $emailSender = new EmailVerification();
        try {
            $emailSender->sendStatusEmail($student_email, $student_name, $panel_id, $action);
        } catch (Exception $e) {
            // Log email error but don't stop the process
            error_log("Email notification failed: " . $e->getMessage());
        }

        header('Location: admin_dashboard.php');
        exit;
    } catch (Exception $e) {
        $_SESSION['error'] = "Error updating status: " . $e->getMessage();
    }
}

// --- KPI COUNTS ---
$total_panels = $pdo->query("SELECT COUNT(*) FROM panels")->fetchColumn();
$pending_panels = $pdo->query("SELECT COUNT(*) FROM panels WHERE status = 'pending'")->fetchColumn();
$approved_panels = $pdo->query("SELECT COUNT(*) FROM panels WHERE status = 'approved'")->fetchColumn();
$rejected_panels = $pdo->query("SELECT COUNT(*) FROM panels WHERE status = 'rejected'")->fetchColumn();

// --- FETCH PANELS ---
$panels_stmt = $pdo->query("
    SELECT p.id, p.thesis_title, p.defense_date, p.defense_time, p.defense_end_time, p.venue, p.status,
           s.full_name AS student_name, s.course, p.panel_members
    FROM panels p
    JOIN students s ON p.student_id = s.id
    ORDER BY p.defense_date, p.defense_time
");
$panels = $panels_stmt->fetchAll(PDO::FETCH_ASSOC);

// --- FETCH TEACHERS ---
$teachers = $pdo->query("SELECT id, full_name FROM teachers")->fetchAll(PDO::FETCH_KEY_PAIR);

// --- PANEL MEMBERS HELPER ---
function get_panel_members($panel_members_csv, $all_teachers) {
    $ids = array_filter(explode(',', $panel_members_csv));
    $names = [];
    foreach ($ids as $id) {
        if (isset($all_teachers[$id])) {
            $names[] = $all_teachers[$id];
        }
    }
    return !empty($names) ? implode(', ', $names) : 'No panel assigned';
}

// --- FLASH MESSAGES ---
$success = $_SESSION['success'] ?? '';
unset($_SESSION['success']);
$error = $_SESSION['error'] ?? '';
unset($_SESSION['error']);

// --- ADMIN NOTIFICATION COUNT ---
$unread_count = count_unread_notifications($_SESSION['teacher_id']);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="admin_dashboard.css">

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2"></script>
</head>
<body>
<header>
    <h2>Admin Dashboard</h2>
    <nav>
        <span>Welcome, <?= htmlspecialchars($_SESSION['teacher_name'] ?? 'Admin') ?></span>
        <a href="admin_dashboard.php" class="nav-link">Dashboard</a>
        <a href="lists_reports.php" class="nav-link">All Lists / Reports</a>

        <!-- Notification Bell -->
        <div class="notification-bell">
            <a href="view_notifications.php">
                🔔 <?php if($unread_count > 0) echo "($unread_count)"; ?>
            </a>
        </div>

        <a href="logout.php">Logout</a>
    </nav>
</header>

<div class="container">

    <!-- DONUT CHART KPI -->
    <section class="kpi-section">
        <h3>Panel Status Overview</h3>
        <canvas id="kpiPieChart" width="400" height="300"></canvas>
    </section>

    <?php if ($success): ?>
        <p class="msg-success"><?= htmlspecialchars($success) ?></p>
    <?php endif; ?>
    <?php if ($error): ?>
        <p class="msg-error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <h3>All Submitted Thesis Schedules</h3>
    <table>
        <tr>
            <th>ID</th>
            <th>Student</th>
            <th>Course</th>
            <th>Thesis Title</th>
            <th>Panel Members</th>
            <th>Date</th>
            <th>Time</th>
            <th>Venue</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php if ($panels): ?>
            <?php foreach ($panels as $panel): ?>
                <tr>
                    <td><?= htmlspecialchars($panel['id']) ?></td>
                    <td><?= htmlspecialchars($panel['student_name']) ?></td>
                    <td><?= htmlspecialchars($panel['course']) ?></td>
                    <td><?= htmlspecialchars($panel['thesis_title']) ?></td>
                    <td><?= htmlspecialchars(get_panel_members($panel['panel_members'], $teachers)) ?></td>
                    <td><?= htmlspecialchars($panel['defense_date']) ?></td>
                    <td><?= htmlspecialchars(date('h:i A', strtotime($panel['defense_time']))) ?> - <?= htmlspecialchars(date('h:i A', strtotime($panel['defense_end_time']))) ?></td>
                    <td><?= htmlspecialchars($panel['venue']) ?></td>
                    <td><?= htmlspecialchars(ucfirst($panel['status'])) ?></td>
                    <td>
                        <?php if ($panel['status'] === 'pending'): ?>
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="panel_id" value="<?= $panel['id'] ?>">
                                <button type="submit" name="action" value="approve" class="approve">Approve</button>
                                <button type="submit" name="action" value="reject" class="reject">Reject</button>
                            </form>
                        <?php else: ?>
                            <?= htmlspecialchars(ucfirst($panel['status'])) ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="10">No schedules found.</td></tr>
        <?php endif; ?>
    </table>
</div>

<!-- DONUT CHART SCRIPT: PERCENTAGE INSIDE, COUNT IN LEGEND -->
<script>
const ctx = document.getElementById('kpiPieChart').getContext('2d');

new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: [
            'Pending (<?= $pending_panels ?>)',
            'Approved (<?= $approved_panels ?>)',
            'Rejected (<?= $rejected_panels ?>)'
        ],
        datasets: [{
            data: [
                <?= $pending_panels ?>,
                <?= $approved_panels ?>,
                <?= $rejected_panels ?>
            ],
            backgroundColor: ['#f57c00', '#388e3c', '#c62828'],
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        cutout: '50%',
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    font: { size: 14 }
                }
            },
            title: {
                display: true,
                text: 'Thesis Panel Status Distribution'
            },
            datalabels: {
                color: '#fff',
                font: { weight: 'bold', size: 14 },
                formatter: (value, context) => {
                    let total = context.chart.data.datasets[0].data.reduce((a,b) => a+b, 0);
                    let percentage = ((value / total) * 100).toFixed(1);
                    return percentage + '%';
                }
            }
        }
    },
    plugins: [ChartDataLabels]
});
</script>

</body>
</html>