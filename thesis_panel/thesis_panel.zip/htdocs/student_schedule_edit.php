<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'init.php';

// Ensure student is logged in
if (empty($_SESSION['student_id'])) {
    header('Location: student_login.php');
    exit;
}

$student_id = (int)$_SESSION['student_id'];
$panel_id = (int)($_GET['id'] ?? 0);

if ($panel_id <= 0) {
    die('Invalid panel ID.');
}

// Fetch current panel and check access
$stmt = $pdo->prepare("SELECT * FROM panels WHERE id = ? AND student_id = ?");
$stmt->execute([$panel_id, $student_id]);
$panel = $stmt->fetch();

if (!$panel) {
    die('Schedule not found or not authorized.');
}

if ($panel['status'] !== 'pending') {
    die('Only PENDING schedules can be edited.');
}

$errors = [];
$success = '';

// Fetch data
$teachers = $pdo->query("SELECT id, full_name, department FROM teachers WHERE is_admin = 0 ORDER BY full_name")->fetchAll();
$rooms = $pdo->query("SELECT room_name FROM rooms ORDER BY room_name")->fetchAll(PDO::FETCH_COLUMN);

// Pre-fill values
$thesis_title = $panel['thesis_title'];
$defense_date = $panel['defense_date'];
$defense_time = $panel['defense_time'];
$venue = $panel['venue'];
$selected_members = explode(',', $panel['panel_members']);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $thesis_title = trim($_POST['thesis_title'] ?? '');
    $defense_date = $_POST['defense_date'] ?? '';
    $defense_time = $_POST['defense_time'] ?? '';
    $venue = trim($_POST['venue'] ?? '');
    $new_members = $_POST['panel_members'] ?? [];
    $panel_member_ids = array_map('intval', $new_members);

    if (empty($thesis_title) || empty($defense_date) || empty($defense_time) || empty($venue) || count($panel_member_ids) < 1) {
        $errors[] = "Please fill in all fields and select at least one panel member.";
    } elseif ($defense_date < date('Y-m-d')) {
        $errors[] = "Cannot schedule a panel for a past date.";
    } else {
        // Calculate end time (assuming 1 hour duration)
        $defense_end_time = date('H:i:s', strtotime($defense_time) + 3600);
        
        // Check conflicts using your existing function
        // Your check_conflicts expects: ($pdo, $date, $start_time, $end_time, $panel_members, $venue, $exclude_id)
        $conflicts = check_conflicts($pdo, $defense_date, $defense_time, $defense_end_time, $panel_member_ids, $venue, $panel_id);

        if (!empty($conflicts)) {
            $errors = array_merge($errors, $conflicts);
        } else {
            $panel_members_csv = implode(',', $panel_member_ids);
            
            // Update with end_time included
            $stmt = $pdo->prepare("
                UPDATE panels
                SET thesis_title = ?, 
                    panel_members = ?, 
                    defense_date = ?, 
                    defense_time = ?, 
                    defense_end_time = ?,
                    venue = ?, 
                    status = 'pending'
                WHERE id = ? AND student_id = ?
            ");
            $stmt->execute([
                $thesis_title, 
                $panel_members_csv, 
                $defense_date, 
                $defense_time, 
                $defense_end_time,
                $venue, 
                $panel_id, 
                $student_id
            ]);

            $_SESSION['success'] = 'Schedule updated successfully.';
            header('Location: student_dashboard.php');
            exit;
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Panel Schedule ID: <?= htmlspecialchars($panel_id) ?></title>
    <link rel="stylesheet" href="student_edit.css">
</head>
<body>
<div class="container">
    <header>
        <h2>Edit Thesis Panel Schedule</h2>
        <p class="subtext">Schedule ID: <?= htmlspecialchars($panel_id) ?></p>
        <nav>
            <a href="student_dashboard.php" class="nav-link">Back to Dashboard</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </nav>
    </header>

    <?php if (!empty($errors)): ?>
        <ul class="errors">
            <?php foreach ($errors as $e): ?>
                <li><?= htmlspecialchars($e) ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <form method="post" action="" class="edit-form">
        <label>Thesis Title:
            <input type="text" name="thesis_title" required value="<?= htmlspecialchars($thesis_title) ?>">
        </label>

        <label>Date:
            <input type="date" name="defense_date" required min="<?= date('Y-m-d') ?>" value="<?= htmlspecialchars($defense_date) ?>">
        </label>

        <label>Time (Defense will last 1 hour):
            <input type="time" name="defense_time" required step="3600" value="<?= htmlspecialchars($defense_time) ?>">
        </label>

        <label>Venue/Room:
            <select name="venue" required>
                <option value="">-- Select Room --</option>
                <?php foreach ($rooms as $room): ?>
                    <option value="<?= htmlspecialchars($room) ?>" <?= ($venue === $room) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($room) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>

        <fieldset class="panel-members">
            <legend>Panel Members (Check availability carefully!)</legend>
            <div class="member-list">
                <?php foreach ($teachers as $t): 
                    $checked = in_array((string)$t['id'], $selected_members) ? 'checked' : '';
                ?>
                    <label>
                        <input type="checkbox" name="panel_members[]" value="<?= htmlspecialchars($t['id']) ?>" <?= $checked ?>>
                        <?= htmlspecialchars($t['full_name'] . ' (' . $t['department'] . ')') ?>
                    </label>
                <?php endforeach; ?>
            </div>
        </fieldset>

        <button type="submit" class="btn-primary">Update Schedule Request</button>
    </form>
</div>
</body>
</html>