<?php
session_start();
require_once 'database.php';
require_once 'functions.php';

if (empty($_SESSION['teacher_id'])) {
    header('Location: login.php');
    exit;
}

$teacher_id = (int)$_SESSION['teacher_id'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_name = trim($_POST['student_name']);
    $thesis_title = trim($_POST['thesis_title']);
    $date = $_POST['scheduled_date'];
    $time = $_POST['scheduled_time'];
    $venue = trim($_POST['venue']);
    $panel_members = $_POST['panel_members'] ?? [];

    if (!is_array($panel_members)) {
        $panel_members = [$panel_members];
    }

    $conflicts = check_conflicts($pdo, $date, $time, $panel_members);

    if ($conflicts && count($conflicts) > 0) {
        $message = " One or more selected panel members are already booked for $date at $time.";
    } else {
        $panel_member_ids = implode(',', $panel_members);
        $stmt = $pdo->prepare("
            INSERT INTO panels (creator_id, student_name, thesis_title, scheduled_date, scheduled_time, venue, panel_members)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$teacher_id, $student_name, $thesis_title, $date, $time, $venue, $panel_member_ids]);

        $message = "Panel schedule request submitted successfully (waiting for admin approval).";

        // --- SYSTEM NOTIFICATION for Admin ---
        require_once 'notification_functions.php';
        $admin_id = 1; // Replace with actual admin user ID
        $notif_msg = "New panel schedule request: $student_name ($thesis_title) on $date at $time";
        add_notification($admin_id, 'new_panel', $notif_msg);

        // --- EMAIL NOTIFICATION to Admin ---
        require_once 'email_functions.php';
        $email_subject = "New Panel Schedule Request";
        $email_body = "A new thesis panel request has been submitted by $student_name.<br>Title: $thesis_title<br>Date: $date<br>Time: $time<br>Venue: $venue";
        send_email('admin@example.com', $email_subject, $email_body); // Replace with admin email
    }
}

// Fetch teachers for dropdown
$stmt = $pdo->prepare("SELECT id, full_name FROM teachers WHERE is_admin = 0");
$stmt->execute();
$teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Create Thesis Panel Schedule</title>
</head>
<body>
  <h2>Create Thesis Panel Schedule</h2>
  <p><a href="dashboard.php">Back to Dashboard</a></p>

  <?php if ($message): ?>
    <p><strong><?= htmlspecialchars($message) ?></strong></p>
  <?php endif; ?>

  <form method="post" action="">
    <label>Student Name:</label><br>
    <input type="text" name="student_name" required><br><br>

    <label>Thesis Title:</label><br>
    <input type="text" name="thesis_title" required><br><br>

    <label>Date:</label><br>
    <input type="date" name="scheduled_date" required><br><br>

    <label>Time:</label><br>
    <input type="time" name="scheduled_time" required><br><br>

    <label>Venue:</label><br>
    <input type="text" name="venue" required><br><br>

    <label>Select Panel Members:</label><br>
    <?php foreach ($teachers as $t): ?>
      <input type="checkbox" name="panel_members[]" value="<?= $t['id'] ?>"> 
      <?= htmlspecialchars($t['full_name']) ?><br>
    <?php endforeach; ?>
    <br>

    <button type="submit">Create Schedule</button>
  </form>
</body>
</html>
