<?php
require_once 'database.php';
require_once 'functions.php';
require_once 'notification_functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if student not logged in
if (empty($_SESSION['student_id'])) {
    header('Location: student_login.php');
    exit;
}

$student_id = (int)$_SESSION['student_id'];
$student_name = $_SESSION['student_name'] ?? 'Student';
$errors = [];
$success = '';

// Fetch all teachers (non-admin)
$teachers = $pdo->query("SELECT id, full_name, department FROM teachers WHERE is_admin = 0 ORDER BY full_name")
    ->fetchAll(PDO::FETCH_ASSOC);

// Fetch teachers’ availability
$availability_raw = $pdo->query("SELECT teacher_id, available_date, start_time, end_time FROM availability ORDER BY available_date, start_time")
    ->fetchAll(PDO::FETCH_ASSOC);

$availability = [];
foreach ($availability_raw as $a) {
    $availability[$a['teacher_id']][] = $a['available_date'] . ' (' .
        date('h:i A', strtotime($a['start_time'])) . ' - ' .
        date('h:i A', strtotime($a['end_time'])) . ')';
}

// Fetch available rooms
$rooms = $pdo->query("SELECT room_name FROM rooms ORDER BY room_name")->fetchAll(PDO::FETCH_COLUMN);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['thesis_title'] ?? '');
    $date = $_POST['defense_date'] ?? '';
    $start_time = $_POST['defense_start_time'] ?? '';
    $end_time = $_POST['defense_end_time'] ?? '';
    $venue = trim($_POST['venue'] ?? '');
    $panel_members = $_POST['panel_members'] ?? [];
    $panel_member_ids = array_map('intval', $panel_members);

    // Basic validation
    if (empty($title) || empty($date) || empty($start_time) || empty($end_time) || empty($venue) || count($panel_member_ids) < 1) {
        $errors[] = "Please fill in all fields and select at least one panel member.";
    } elseif ($date < date('Y-m-d')) {
        $errors[] = "Cannot schedule a panel for a past date.";
    } elseif ($start_time >= $end_time) {
        $errors[] = "End time must be later than start time.";
    } else {
        $conflicts = check_conflicts($pdo, $date, $start_time, $end_time, $panel_member_ids, $venue);

        if (!empty($conflicts)) {
            $errors = array_merge($errors, $conflicts);
        } else {
            // Insert panel schedule
            $panel_members_csv = implode(',', $panel_member_ids);
            $stmt = $pdo->prepare("
                INSERT INTO panels (student_id, thesis_title, panel_members, defense_date, defense_time, defense_end_time, venue, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
            ");
            $stmt->execute([$student_id, $title, $panel_members_csv, $date, $start_time, $end_time, $venue]);

            // --- Notify all admins ---
            $admins = $pdo->query("SELECT id FROM teachers WHERE is_admin = 1")->fetchAll(PDO::FETCH_COLUMN);
            foreach ($admins as $admin_id) {
                add_notification(
                    $admin_id,
                    'panel_request',
                    "New thesis panel request submitted by {$student_name}: {$title}",
                    'view_notifications.php'
                );
            }

            // --- Notify selected panel members ---
            foreach ($panel_member_ids as $teacher_id) {
                add_notification(
                    $teacher_id,
                    'assigned_panel',
                    "You are assigned as panel for {$student_name}'s thesis: {$title}",
                    'dashboard.php'
                );
            }

            $_SESSION['success'] = 'Schedule request submitted successfully and is awaiting admin approval.';
            header('Location: student_dashboard.php');
            exit;
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Request New Panel</title>
    <link rel="stylesheet" href="student_schedule_create.css">
</head>
<body>
<div class="container">
    <div class="header-row">
        <h2>Request Thesis Panel Schedule</h2>
        <a href="student_dashboard.php" class="btn-back">← Back to Dashboard</a>
    </div>

    <?php if (!empty($errors)): ?>
        <ul class="error">
            <?php foreach ($errors as $e): ?>
                <li><?= htmlspecialchars($e) ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <form method="post" action="">
        <label>Thesis Title:</label>
        <input type="text" name="thesis_title" required value="<?= htmlspecialchars($_POST['thesis_title'] ?? '') ?>">

        <label>Date:</label>
        <input type="date" name="defense_date" required min="<?= date('Y-m-d') ?>" value="<?= htmlspecialchars($_POST['defense_date'] ?? '') ?>">

        <label>Start Time:</label>
        <input type="time" name="defense_start_time" required step="1800" value="<?= htmlspecialchars($_POST['defense_start_time'] ?? '') ?>">

        <label>End Time:</label>
        <input type="time" name="defense_end_time" required step="1800" value="<?= htmlspecialchars($_POST['defense_end_time'] ?? '') ?>">

        <label>Venue/Room:</label>
        <select name="venue" required>
            <option value="">-- Select Room --</option>
            <?php foreach ($rooms as $room): ?>
                <option value="<?= htmlspecialchars($room) ?>" <?= (($_POST['venue'] ?? '') === $room) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($room) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <fieldset>
            <legend>Panel Members (Check their availability below)</legend>
            <?php foreach ($teachers as $t):
                $checked = in_array((string)$t['id'], $_POST['panel_members'] ?? []) ? 'checked' : '';
            ?>
                <label>
                    <input type="checkbox" name="panel_members[]" value="<?= htmlspecialchars($t['id']) ?>" <?= $checked ?>>
                    <strong><?= htmlspecialchars($t['full_name'] . ' (' . $t['department'] . ')') ?></strong>
                </label>

                <?php if (!empty($availability[$t['id']])): ?>
                    <ul class="availability-list">
                        <?php foreach ($availability[$t['id']] as $slot): ?>
                            <li><?= htmlspecialchars($slot) ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p class="availability-list">No available slots listed.</p>
                <?php endif; ?>
            <?php endforeach; ?>
        </fieldset>

        <button type="submit">Submit Schedule Request</button>
    </form>
</div>
</body>
</html>
