<?php
// config.php - Environment Configuration for InfinityFree Deployment
// IMPORTANT: Update these values for your InfinityFree account

// ============================================================================
// INFINITYFREE DATABASE CONFIGURATION
// ============================================================================
// Get these credentials from your InfinityFree control panel:
// cPanel > Databases > MySQL Databases
// cPanel > Databases > MySQL Users

$DB_HOST = 'localhost'; // Usually localhost on InfinityFree
$DB_NAME = 'Your_Database_Name_Here'; // Replace with your actual database name
$DB_USER = 'Your_Username_Here'; // Replace with your database username
$DB_PASS = 'Your_Password_Here'; // Replace with your database password

// ============================================================================
// EMAIL CONFIGURATION FOR INFINITYFREE
// ============================================================================
// InfinityFree supports Gmail SMTP. Use your Gmail account or update credentials
// For better reliability on free hosting, consider using:
// 1. Gmail SMTP (as currently configured)
// 2. SendGrid (free tier available)
// 3. Mailgun (free tier available)

$EMAIL_HOST = 'smtp.gmail.com';
$EMAIL_USER = 'your-email@gmail.com'; // Replace with your Gmail
$EMAIL_PASS = 'your-app-password'; // Use Gmail App Password (not regular password)
$EMAIL_PORT = 465;
$EMAIL_FROM = 'your-email@gmail.com';
$EMAIL_FROM_NAME = 'PANEL';

// For production, consider storing sensitive data differently
// You can also use environment variables if InfinityFree supports them

// ============================================================================
// APPLICATION CONFIGURATION
// ============================================================================
$APP_URL = 'https://yourdomain.infinityfree.com'; // Replace with your actual domain
$APP_ROOT = dirname(__FILE__);

// ============================================================================
// SESSION CONFIGURATION
// ============================================================================
define('SESSION_TIMEOUT', 3600); // 1 hour in seconds

// ============================================================================
// ERROR REPORTING
// ============================================================================
// Set to false in production to hide error details from users
error_reporting(E_ALL);
ini_set('display_errors', 1); // Change to 0 in production
ini_set('log_errors', 1);
ini_set('error_log', $APP_ROOT . '/error.log');
?>
