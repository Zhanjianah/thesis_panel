<?php
// init.php - central initializer for the project

// 1. Start session safely
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. Load database connection
require_once 'database.php';

// 3. Load core functions
require_once 'functions.php';

// 4. Load notifications (optional, if your pages use them)
require_once 'notification_functions.php';
