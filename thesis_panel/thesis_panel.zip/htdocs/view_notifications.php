<?php
require_once 'database.php';
require_once 'functions.php';
require_once 'notification_functions.php';

// Start session only if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!is_logged_in() || !is_admin()) {
    header('Location: login.php');
    exit;
}

$user_id = current_user_id();

// Handle mark as read
if (!empty($_GET['mark_read'])) {
    mark_notification_as_read((int)$_GET['mark_read']);
    header('Location: view_notifications.php');
    exit;
}

// Fetch all notifications
$notifications = get_all_notifications($user_id);
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>All Notifications</title>
    <link rel="stylesheet" href="view_notifications.css">
</head>
<body>
<h2>All Notifications</h2>
<a href="admin_dashboard.php" class="back-link"> Back to Dashboard</a>

<table class="notification-table">
    <thead>
        <tr>
            <th>#</th>
            <th>Type</th>
            <th>Message</th>
            <th>Status</th>
            <th>Action</th>
            <th>Date</th>
        </tr>
    </thead>
    <tbody>
    <?php if (!empty($notifications)): ?>
        <?php foreach ($notifications as $i => $n): ?>
            <tr class="<?= $n['is_read'] ? '' : 'notification-unread' ?>">
                <td><?= $i + 1 ?></td>
                <td><?= htmlspecialchars($n['type']) ?></td>
                <td><?= htmlspecialchars($n['message']) ?></td>
                <td><?= $n['is_read'] ? 'Read' : 'Unread' ?></td>
                <td class="action-links">
                    <?php if ($n['link']): ?>
                        <a href="<?= htmlspecialchars($n['link']) ?>?mark_read=<?= $n['id'] ?>">View</a>
                    <?php endif; ?>
                    <?php if (!$n['is_read']): ?>
                        <a href="?mark_read=<?= $n['id'] ?>">Mark as Read</a>
                    <?php endif; ?>
                </td>
                <td><?= htmlspecialchars($n['created_at']) ?></td>
            </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr><td colspan="6">No notifications found.</td></tr>
    <?php endif; ?>
    </tbody>
</table>
</body>
</html>
