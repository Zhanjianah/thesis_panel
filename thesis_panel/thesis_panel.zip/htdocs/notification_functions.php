<?php
require_once 'database.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Add a notification for a user
 */
function add_notification($user_id, $type, $message, $link = null) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, type, message, link) VALUES (?, ?, ?, ?)");
    $stmt->execute([$user_id, $type, $message, $link]);
}

/**
 * Get latest notifications for a user
 */
function get_notifications($user_id, $limit = 10) {
    global $pdo;
    $limit = (int)$limit;
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT $limit");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Count unread notifications
 */
function count_unread_notifications($user_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$user_id]);
    return (int)$stmt->fetchColumn();
}

/**
 * Mark as read
 */
function mark_notification_as_read($id) {
    global $pdo;
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ?");
    $stmt->execute([$id]);
}

/**
 * Get all notifications
 */
function get_all_notifications($user_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Get correct dashboard link for a user type
 */
function get_dashboard_link() {
    if (!empty($_SESSION['teacher_id'])) {
        return is_admin() ? 'admin_dashboard.php' : 'dashboard.php';
    }
    if (!empty($_SESSION['student_id'])) {
        return 'student_dashboard.php';
    }
    return 'login.php';
}
?>
