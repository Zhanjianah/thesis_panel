<?php
require_once 'database.php';
require_once 'notification_functions.php';
if (session_status() === PHP_SESSION_NONE) session_start();

if (!empty($_GET['id']) && isset($_SESSION['teacher_id'])) {
    mark_notification_as_read((int)$_GET['id']);
}
header('Location: admin_dashboard.php');
