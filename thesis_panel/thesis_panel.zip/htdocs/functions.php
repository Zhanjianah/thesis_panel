<?php
require_once 'database.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// --- AUTH FUNCTIONS (Teacher/Admin) ---
function is_logged_in() {
    return isset($_SESSION['teacher_id']);
}

function current_user_id() {
    return (int)($_SESSION['teacher_id'] ?? 0);
}

function is_admin() {
    return (int)($_SESSION['is_admin'] ?? 0) === 1;
}

// --- CORE CONFLICT CHECKING FUNCTION ---
/**
 * Checks for scheduling conflicts based on panel members, time slots, and venue.
 */
function check_conflicts($pdo, $date, $start_time, $end_time, $panel_members, $venue, $exclude_id = null) {
    $conflicts = [];

    if (empty($panel_members)) {
        $conflicts[] = "At least one panel member must be selected.";
        return $conflicts;
    }

    // --- 1. Check Teacher Availability (requested time must fit within availability) ---
    $placeholders = implode(',', array_fill(0, count($panel_members), '?'));
    $params = array_merge($panel_members, [$date, $start_time, $end_time]);

    $stmt = $pdo->prepare("
        SELECT t.full_name
        FROM teachers t
        WHERE t.id IN ($placeholders)
        AND t.id NOT IN (
            SELECT teacher_id
            FROM availability
            WHERE available_date = ?
            AND start_time <= ?
            AND end_time >= ?
        )
    ");
    $stmt->execute($params);
    $unavailable_teachers = $stmt->fetchAll(PDO::FETCH_COLUMN);

    if (!empty($unavailable_teachers)) {
        $conflicts[] = "The following panel members are unavailable at this time: " . implode(', ', $unavailable_teachers) . ".";
    }

    // --- 2. Check if panel member is already booked (overlapping time) ---
    $sql_member_conflict = "
        SELECT p.id
        FROM panels p
        WHERE p.defense_date = ?
          AND NOT (? >= DATE_ADD(p.defense_time, INTERVAL 1 HOUR) OR ? <= p.defense_time)
          AND p.status IN ('pending', 'approved')
          AND (";
    $params2 = [$date, $start_time, $end_time];
    $member_conditions = [];
    foreach ($panel_members as $member_id) {
        $member_conditions[] = "FIND_IN_SET(?, p.panel_members)";
        $params2[] = $member_id;
    }
    $sql_member_conflict .= implode(' OR ', $member_conditions) . ")";
    if ($exclude_id !== null) {
        $sql_member_conflict .= " AND p.id != ?";
        $params2[] = $exclude_id;
    }
    $stmt = $pdo->prepare($sql_member_conflict);
    $stmt->execute($params2);
    $member_conflicts = $stmt->fetchAll(PDO::FETCH_COLUMN);

    if (!empty($member_conflicts)) {
        $conflicts[] = "One or more selected panel members are already booked for another panel at this time.";
    }

    // --- 3. Check Venue Conflict ---
    $sql_venue_conflict = "
        SELECT p.id
        FROM panels p
        WHERE p.defense_date = ?
          AND NOT (? >= DATE_ADD(p.defense_time, INTERVAL 1 HOUR) OR ? <= p.defense_time)
          AND p.venue = ?
          AND p.status IN ('pending', 'approved')
    ";
    $params3 = [$date, $start_time, $end_time, $venue];
    if ($exclude_id !== null) {
        $sql_venue_conflict .= " AND p.id != ?";
        $params3[] = $exclude_id;
    }
    $stmt = $pdo->prepare($sql_venue_conflict);
    $stmt->execute($params3);
    $venue_conflicts = $stmt->fetchAll();

    if (!empty($venue_conflicts)) {
        $conflicts[] = "The venue '{$venue}' is already booked at this time.";
    }

    return $conflicts;
}

// ============================================================================
// NEW FUNCTIONS ADDED BELOW - Download/Print Schedule Functionality
// These functions do NOT modify any existing logic above
// ============================================================================

/**
 * NEW FUNCTION: Fetch approved schedule details for a specific student and panel
 * Used for generating downloadable/printable schedules
 */
function get_approved_schedule_details($pdo, $student_id, $panel_id) {
    // First, let's try to detect the correct column name by checking the students table
    try {
        // Try with common column names for student name
        $possibleColumns = ['student_name', 'name', 'full_name', 'fullname'];
        $studentNameColumn = 'student_name'; // default
        
        // Try to get the first student to see which column exists
        foreach ($possibleColumns as $col) {
            try {
                $testStmt = $pdo->query("SELECT $col FROM students LIMIT 1");
                if ($testStmt) {
                    $studentNameColumn = $col;
                    break;
                }
            } catch (PDOException $e) {
                // Column doesn't exist, try next one
                continue;
            }
        }
        
        $stmt = $pdo->prepare("
            SELECT 
                p.id,
                p.thesis_title,
                p.defense_date,
                p.defense_time,
                p.defense_end_time,
                p.venue,
                p.panel_members,
                p.status,
                s.$studentNameColumn as student_name,
                s.email as student_email,
                r.room_name as venue_name,
                r.building as venue_building
            FROM panels p
            INNER JOIN students s ON s.id = p.student_id
            LEFT JOIN rooms r ON r.room_name = p.venue
            WHERE p.id = ? AND p.student_id = ? AND p.status = 'approved'
        ");
        $stmt->execute([$panel_id, $student_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        // If all else fails, get data without student name from students table
        // We can use the session student_name instead
        $stmt = $pdo->prepare("
            SELECT 
                p.id,
                p.thesis_title,
                p.defense_date,
                p.defense_time,
                p.defense_end_time,
                p.venue,
                p.panel_members,
                p.status,
                r.room_name as venue_name,
                r.building as venue_building
            FROM panels p
            LEFT JOIN rooms r ON r.room_name = p.venue
            WHERE p.id = ? AND p.student_id = ? AND p.status = 'approved'
        ");
        $stmt->execute([$panel_id, $student_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Add student name from session if available
        if ($result && isset($_SESSION['student_name'])) {
            $result['student_name'] = $_SESSION['student_name'];
            $result['student_email'] = $_SESSION['student_email'] ?? '';
        }
        
        return $result;
    }
}

/**
 * NEW FUNCTION: Get panel member names from comma-separated IDs
 * Used for displaying panel members in the printable schedule
 */
function get_panel_member_names($pdo, $panel_members_csv) {
    if (empty($panel_members_csv)) {
        return [];
    }
    
    $ids = explode(',', $panel_members_csv);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    
    $stmt = $pdo->prepare("
        SELECT full_name, department 
        FROM teachers 
        WHERE id IN ($placeholders)
        ORDER BY full_name
    ");
    $stmt->execute($ids);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * NEW FUNCTION: Generate HTML content for the schedule
 * This creates a print-friendly HTML page for the approved schedule
 */
function generate_schedule_html($schedule, $panel_members) {
    $thesis_title = htmlspecialchars($schedule['thesis_title']);
    $student_name = htmlspecialchars($schedule['student_name']);
    $defense_date = date('F d, Y', strtotime($schedule['defense_date']));
    $defense_time = date('h:i A', strtotime($schedule['defense_time']));
    $defense_end_time = date('h:i A', strtotime($schedule['defense_end_time']));
    $venue = htmlspecialchars($schedule['venue_name'] ?: $schedule['venue']);
    $venue_building = htmlspecialchars($schedule['venue_building'] ?? '');
    
    $html = '
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Thesis Defense Schedule - ' . $thesis_title . '</title>
        <style>
            @media print {
                body {
                    margin: 0;
                    padding: 20px;
                }
                .no-print {
                    display: none !important;
                }
            }
            
            body {
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
            }
            
            .schedule-container {
                border: 2px solid #333;
                padding: 30px;
                background: #fff;
            }
            
            .header {
                text-align: center;
                margin-bottom: 30px;
                border-bottom: 3px solid #333;
                padding-bottom: 20px;
            }
            
            .header h1 {
                margin: 0 0 10px 0;
                font-size: 24px;
                text-transform: uppercase;
            }
            
            .header h2 {
                margin: 0;
                font-size: 18px;
                color: #666;
            }
            
            .approved-stamp {
                display: inline-block;
                border: 3px solid #28a745;
                color: #28a745;
                padding: 5px 15px;
                font-weight: bold;
                text-transform: uppercase;
                margin-top: 10px;
            }
            
            .section {
                margin-bottom: 25px;
            }
            
            .section-title {
                font-weight: bold;
                font-size: 16px;
                color: #333;
                margin-bottom: 10px;
                text-transform: uppercase;
                border-bottom: 2px solid #ccc;
                padding-bottom: 5px;
            }
            
            .info-row {
                display: flex;
                margin-bottom: 10px;
            }
            
            .info-label {
                font-weight: bold;
                min-width: 180px;
            }
            
            .info-value {
                flex: 1;
            }
            
            .panel-member {
                padding: 5px 0;
                border-bottom: 1px dotted #ccc;
            }
            
            .panel-member:last-child {
                border-bottom: none;
            }
            
            .footer {
                margin-top: 40px;
                padding-top: 20px;
                border-top: 2px solid #333;
                font-size: 12px;
                color: #666;
                text-align: center;
            }
            
            .print-buttons {
                text-align: center;
                margin-bottom: 20px;
                padding: 15px;
                background: #f8f9fa;
                border-radius: 5px;
            }
            
            .btn {
                display: inline-block;
                padding: 10px 20px;
                margin: 0 5px;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
                cursor: pointer;
                border: none;
                font-size: 14px;
            }
            
            .btn-print {
                background: #007bff;
                color: white;
            }
            
            .btn-print:hover {
                background: #0056b3;
            }
            
            .btn-back {
                background: #6c757d;
                color: white;
            }
            
            .btn-back:hover {
                background: #545b62;
            }
        </style>
    </head>
    <body>
        <div class="print-buttons no-print">
            <button onclick="window.print()" class="btn btn-print">🖨️ Print / Save as PDF</button>
            <a href="student_dashboard.php" class="btn btn-back">← Back to Dashboard</a>
        </div>
        
        <div class="schedule-container">
            <div class="header">
                <h1>Thesis Defense Schedule</h1>
                <h2>Official Approved Schedule</h2>
                <div class="approved-stamp">✓ APPROVED</div>
            </div>
            
            <div class="section">
                <div class="section-title">Student Information</div>
                <div class="info-row">
                    <div class="info-label">Student Name:</div>
                    <div class="info-value">' . $student_name . '</div>
                </div>
                <div class="info-row">
                    <div class="info-label">Thesis Title:</div>
                    <div class="info-value">' . $thesis_title . '</div>
                </div>
            </div>
            
            <div class="section">
                <div class="section-title">Defense Schedule</div>
                <div class="info-row">
                    <div class="info-label">Date:</div>
                    <div class="info-value">' . $defense_date . '</div>
                </div>
                <div class="info-row">
                    <div class="info-label">Time:</div>
                    <div class="info-value">' . $defense_time . ' - ' . $defense_end_time . '</div>
                </div>
                <div class="info-row">
                    <div class="info-label">Venue:</div>
                    <div class="info-value">' . $venue . ($venue_building ? ' (' . $venue_building . ')' : '') . '</div>
                </div>
            </div>
            
            <div class="section">
                <div class="section-title">Panel Members</div>';
    
    if (!empty($panel_members)) {
        foreach ($panel_members as $member) {
            $html .= '
                <div class="panel-member">
                    <strong>' . htmlspecialchars($member['full_name']) . '</strong>
                    <span style="color: #666;"> - ' . htmlspecialchars($member['department']) . '</span>
                </div>';
        }
    } else {
        $html .= '<div class="info-value">No panel members assigned.</div>';
    }
    
    $html .= '
            </div>
            
            <div class="footer">
                <p>This is an official approved thesis defense schedule.</p>
                <p>Generated on ' . date('F d, Y \a\t h:i A') . '</p>
            </div>
        </div>
    </body>
    </html>';
    
    return $html;
}
?>