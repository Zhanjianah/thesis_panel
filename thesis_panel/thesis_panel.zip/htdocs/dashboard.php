<?php
session_start();
require_once 'database.php';
require_once 'functions.php';
require_once 'notification_functions.php';

// Ensure user is logged in
if (!is_logged_in()) {
    header('Location: login.php');
    exit;
}

$teacher_id = current_user_id();
$is_admin = is_admin();
$full_name = $_SESSION['teacher_name'] ?? 'Teacher';

// Redirect admin to admin dashboard
if ($is_admin == 1) {
    header("Location: admin_dashboard.php");
    exit;
}

// Fetch panels where the logged-in teacher is a panel member
$stmt = $pdo->prepare("
    SELECT p.*, s.full_name AS student_name, s.course
    FROM panels p
    JOIN students s ON p.student_id = s.id
    WHERE FIND_IN_SET(?, p.panel_members)
    ORDER BY p.defense_date, p.defense_time
");
$stmt->execute([$teacher_id]);
$panels = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch all teachers as [id => full_name]
$teachers = $pdo->query("SELECT id, full_name FROM teachers")->fetchAll(PDO::FETCH_KEY_PAIR);

// Count unread notifications for bell
$unread_count = count_unread_notifications($teacher_id);

// Helper function to get teacher names from CSV
function get_panel_members($panel_members_csv, $all_teachers) {
    $ids = array_filter(explode(',', $panel_members_csv));
    $names = [];
    foreach ($ids as $id) {
        $id = trim($id);
        if (isset($all_teachers[$id])) {
            $names[] = $all_teachers[$id];
        }
    }
    return implode(', ', $names);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Teacher Dashboard</title>
  <link rel="stylesheet" href="dashboard.css"> 
</head>
<body>
  <div class="dashboard-container">
    <header>
      <h2>Welcome, <?= htmlspecialchars($full_name) ?></h2>
      <nav>
        <a href="availability.php" class="nav-link">Set Your Availability</a>
        <a href="view_notifications_teacher.php" class="notification-bell">
            🔔
            <?php if ($unread_count > 0): ?>
                <span class="badge"><?= $unread_count ?></span>
            <?php endif; ?>
        </a>
        <a href="logout.php" class="logout-btn">Logout</a>
      </nav>
    </header>

    <main>
      <h3>Your Assigned Thesis Panel Schedules</h3>

      <?php if (empty($panels)): ?>
        <p class="empty">No schedules are currently assigned to you.</p>
      <?php else: ?>
        <table class="data-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Student</th>
              <th>Course</th>
              <th>Thesis Title</th>
              <th>Date</th>
              <th>Time</th>
              <th>Venue</th>
              <th>Panel Members</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($panels as $panel): ?>
              <tr>
                <td><?= htmlspecialchars($panel['id']) ?></td>
                <td><?= htmlspecialchars($panel['student_name']) ?></td>
                <td><?= htmlspecialchars($panel['course']) ?></td>
                <td><?= htmlspecialchars($panel['thesis_title']) ?></td>
                <td><?= htmlspecialchars($panel['defense_date']) ?></td>
                <td><?= htmlspecialchars(date('h:i A', strtotime($panel['defense_time']))) ?></td>
                <td><?= htmlspecialchars($panel['venue']) ?></td>
                <td><?= htmlspecialchars(get_panel_members($panel['panel_members'], $teachers)) ?></td>
                <td class="status <?= 'status-' . htmlspecialchars($panel['status']) ?>">
                  <?= htmlspecialchars(ucfirst($panel['status'])) ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </main>
  </div>
</body>
</html>
