<?php 
session_start(); 
require_once 'functions.php'; 
 
// --- ADMIN CHECK --- 
if (!is_admin()) { 
    header('Location: login.php'); 
    exit; 
} 
?> 
<!DOCTYPE html> 
<html lang="en"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Lists / Reports</title> 
    <link rel="stylesheet" href="lists_reports.css"> 
</head> 
<body> 
<div class="dashboard-container"> 
    <header> 
        <h2>All Lists / Reports</h2> 
        <nav> 
            <a href="admin_dashboard.php" class="nav-link">Dashboard</a> 
            <a href="logout.php" class="logout-btn">Logout</a> 
        </nav> 
    </header> 
 
    <div class="menu-container"> 
        <a href="panel_list.php" class="menu-card"> 
            <h3>Panel List</h3> 
            <p>View all thesis panels</p> 
        </a> 
 
        <a href="student_list.php" class="menu-card"> 
            <h3>Student List</h3> 
            <p>View all registered students</p> 
        </a> 
 
        <a href="teacher_list.php" class="menu-card"> 
            <h3>Teacher List</h3> 
            <p>View all teachers and their panels</p> 
        </a> 
 
        <a href="reports.php" class="menu-card"> 
            <h3>Reports</h3> 
            <p>Generate thesis panel reports</p> 
        </a> 
    </div> 
</div> 
</body> 
</html>