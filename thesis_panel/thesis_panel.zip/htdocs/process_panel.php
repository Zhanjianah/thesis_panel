<?php
// process_panel.php
require_once 'database.php';
require_once 'functions.php';
require_once 'notification_functions.php';
session_start();

$action = $_POST['action'] ?? '';
$id = (int)($_POST['id'] ?? 0);

if ($id <= 0) {
    header('Location: login.php'); // Redirect to login or default if no ID
    exit;
}

// --- Student deletes their own pending panel ---
if ($action === 'student_delete') {
    if (empty($_SESSION['student_id'])) {
        header('Location: student_login.php');
        exit;
    }
    $student_id = (int)$_SESSION['student_id'];
    
    // Only allow deletion of PENDING schedules created by the student
    $stmt = $pdo->prepare("DELETE FROM panels WHERE id = ? AND student_id = ? AND status = 'pending'");
    $stmt->execute([$id, $student_id]);
    
    if ($stmt->rowCount() > 0) {
        $_SESSION['success'] = 'Schedule deleted successfully.';
    } else {
        $_SESSION['error'] = 'Deletion failed. Schedule not found, not owned, or not in PENDING status.';
    }
    header('Location: student_dashboard.php');
    exit;
}

// --- Admin approves or rejects a panel ---
if ($action === 'update_status') {
    if (empty($_SESSION['teacher_id'])) {
        header('Location: login.php');
        exit;
    }

    $status = $_POST['status'] ?? '';
    $title = $_POST['title'] ?? '';

    if (!in_array($status, ['approved', 'rejected'])) {
        $_SESSION['error'] = 'Invalid status.';
        header('Location: admin_dashboard.php');
        exit;
    }

    // Update panel status
    $stmt = $pdo->prepare("UPDATE panels SET status = ? WHERE id = ?");
    $stmt->execute([$status, $id]);

    // Notify the student
    $student_id = $pdo->query("SELECT student_id FROM panels WHERE id = {$id}")->fetchColumn();
    if ($student_id) {
        add_notification(
            $student_id,
            'panel_status',
            "Your thesis panel '{$title}' has been {$status}.",
            "student_dashboard.php"
        );
    }

    $_SESSION['success'] = "Panel has been {$status}.";
    header('Location: admin_dashboard.php');
    exit;
}

// Redirect if no valid action is found
header('Location: login.php');
exit;
?>
