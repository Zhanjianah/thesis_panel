<?php
require_once __DIR__ . "/vendor/autoload.php";
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class EmailVerification
{
    public function getPinEmailBody($recipientName, $pinCode) 
    {
        return "
        <html>
        <body>
            <p>Hello <strong>{$recipientName}</strong>,</p>
            <p>Your verification PIN code is: <strong>{$pinCode}</strong></p>
            <p>Enter this code on the verification page to activate your account.</p>
        </body>
        </html>
        ";
    }

    public function sendVerificationEmail($toEmail, $recipientName, &$pinCode)
    {
        // Generate 6-digit PIN
        $pinCode = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'jaji.zhanjianahtabilin@gmail.com'; // replace with your Gmail
            $mail->Password = 'aqobzqvwcsmarqrs';    // Gmail app password
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;

            $mail->setFrom('jaji.zhanjianahtabilin@gmail.com', 'PANEL');
            $mail->addAddress($toEmail, $recipientName);

            $mail->isHTML(true);
            $mail->Subject = 'Email Verification';
            $mail->Body = $this->getPinEmailBody($recipientName, $pinCode);
            $mail->AltBody = "Hello {$recipientName}, Your verification PIN is: {$pinCode}";

            $mail->send();
        } catch (Exception $e) {
            throw new Exception("Verification email could not be sent: {$mail->ErrorInfo}");
        }
    }

    public function getStatusEmailBody($recipientName, $panelId, $status) 
    {
        $statusColor = $status === 'approved' ? '#388e3c' : '#c62828';
        $statusText = ucfirst($status);
        
        return "
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #f4f4f4; padding: 20px; text-align: center; }
                .content { padding: 20px; background-color: #ffffff; }
                .status-badge { 
                    display: inline-block;
                    padding: 10px 20px;
                    background-color: {$statusColor};
                    color: white;
                    border-radius: 5px;
                    font-weight: bold;
                    margin: 15px 0;
                }
                .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>Panel Defense Schedule Update</h2>
                </div>
                <div class='content'>
                    <p>Hello <strong>{$recipientName}</strong>,</p>
                    <p>Your thesis panel defense schedule request (ID: <strong>{$panelId}</strong>) has been updated.</p>
                    <div style='text-align: center;'>
                        <div class='status-badge'>Status: {$statusText}</div>
                    </div>
                    <p>Please log in to your student dashboard to view more details about your schedule.</p>
                    <p>If you have any questions, please contact your administrator.</p>
                </div>
                <div class='footer'>
                    <p>This is an automated message from the Thesis Panel Scheduling System.</p>
                </div>
            </div>
        </body>
        </html>
        ";
    }

    public function sendStatusEmail($toEmail, $recipientName, $panelId, $status)
    {
        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'jaji.zhanjianahtabilin@gmail.com'; // replace with your Gmail
            $mail->Password = 'aqobzqvwcsmarqrs';    // Gmail app password
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;

            $mail->setFrom('jaji.zhanjianahtabilin@gmail.com', 'PANEL System');
            $mail->addAddress($toEmail, $recipientName);

            $mail->isHTML(true);
            $mail->Subject = "Panel Schedule " . ucfirst($status) . " - ID {$panelId}";
            $mail->Body = $this->getStatusEmailBody($recipientName, $panelId, $status);
            $mail->AltBody = "Hello {$recipientName}, Your panel schedule (ID {$panelId}) has been {$status}.";

            $mail->send();
        } catch (Exception $e) {
            throw new Exception("Status email could not be sent: {$mail->ErrorInfo}");
        }
    }
}
?>